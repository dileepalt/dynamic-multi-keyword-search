from flask import Flask,render_template,request,session,url_for,json
import pandas as pd
import csv
import mysql.connector
import numpy as np
import random
#from Crypto.Cipher import AES
import onetimepad
import string

app = Flask(__name__)


@app.route('/')
def index():
    return render_template("index.html")

@app.route('/register')
def register():

    return render_template("dataowner.html")


@app.route('/dataowner')
def dataowner():

    return render_template("dataowner.html")


@app.route('/datauser')
def datauser():
    return render_template("datauser.html")


@app.route('/trapdoor')
def trapdoor():
    return render_template("trapdoor.html")


@app.route('/logout')
def logout():
    return render_template("index.html")


@app.route('/cloudlogin', methods=['POST', 'GET'])
def cloudlogin():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        if email == 'cloud' and password == 'cloud':
            return render_template("cloud.html")

    return render_template("cloudlogin.html")


@app.route('/dataownerlogin', methods=['POST', 'GET'])
def dataownerlogin():
    global email
    global user
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="",
            database="multicloud"
        )
        mycursor = mydb.cursor()

        sql = "select count(*) from dataownersignup where username= %s and  password=%s"
        val = (email, password)
        user = email
        print(user)
        mycursor.execute(sql, val)
        result = mycursor.fetchone()
        res = result[0]
        print(res)
        mydb.close()
        if int(res) == 1:
            return render_template("dataowner.html")
    return render_template("dataownerlogin.html",msg='failure!!!')


@app.route('/datauserlogin', methods=['POST', 'GET'])
def datauserlogin():
    global email
    global user
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="",
            database="multicloud"
        )
        mycursor = mydb.cursor()

        sql = "select count(*) from datausersignup where username= %s and  password=%s"
        val = (email, password)
        user = email
        print(user)
        mycursor.execute(sql, val)
        result = mycursor.fetchone()
        res = result[0]
        print(res)
        if int(res) == 1:
            return render_template("datauser.html", msg='Failure!!!')
        mydb.close()
    return render_template("datauserlogin.html")


@app.route('/trapdoorlogin', methods=['POST', 'GET'])
def trapdoorlogin():
    global email
    global user
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="",
            database="multicloud"
        )
        mycursor = mydb.cursor()

        sql = "select count(*) from userregister where username= %s and  password=%s"
        val = (email, password)
        user = email
        print(user)
        mycursor.execute(sql, val)
        result = mycursor.fetchone()
        res = result[0]
        print(res)
        if int(res) == 1:
            return render_template("trapdoor.html", msg='Failure!!!')
        mydb.close()
    return render_template("trapdoorlogin.html")

@app.route('/dwregister1')
def dwregister1():
     return render_template("dwregister.html")


@app.route('/dwregister', methods=['POST', 'GET'])
def dwregister():
     if request.method == 'POST':
            name = request.form['name']
            username = request.form['email']
            password = request.form['password']
            mobile = request.form['mobile']
            mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                passwd="",
                database="multicloud"
            )
            mycursor = mydb.cursor()

            sql = "INSERT INTO dataownersignup (name,username,password,mobile) VALUES (%s, %s, %s, %s)"
            val = (name, username, password, mobile)
            mycursor.execute(sql, val)
            mydb.commit()
     return render_template("dwregister.html", msg='success')

@app.route('/duregister1')
def duregister1():
    return render_template('duregister.html')

@app.route('/duregister', methods=['POST', 'GET'])
def duregister():
     if request.method == 'POST':
            name = request.form['name']
            username = request.form['email']
            password = request.form['password']
            mobile = request.form['mobile']
            mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                passwd="",
                database="multicloud"
            )
            mycursor = mydb.cursor()

            sql = "INSERT INTO datausersignup (name,username,password,mobile) VALUES (%s, %s, %s, %s)"
            val = (name, username, password, mobile)
            mycursor.execute(sql, val)
            mydb.commit()
     return render_template("duregister.html", msg='success')

@app.route('/udocuments1')
def udocuments1():
    return render_template('udocuments.html')

@app.route('/udocuments', methods=['POST', 'GET'])
def udocuments():
    if request.method == 'POST':

        oname = request.form['oname']
        fname = request.form['fname']
        status = 'nil'
        permission = 'nil'

        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="",
            database="multicloud"
        )
        mycursor = mydb.cursor()

        sql = "select count(*) from uploadedfiles where filee=%s"
        val = (fname,)
        mycursor.execute(sql, val)
        result = mycursor.fetchone()
        count = result[0]
        print(count)
        if count == 0:
            sql = "insert into uploadedfiles(private_key,trapdoor_key,username,filee,status,permission) values(%s,%s,%s,%s,%s,%s)"
            key1 = random.randint(1, 10000)
            key1 = str(key1)

            file_name = "e:/files/" + fname + ".txt"
            f = open(file_name, 'r')
            fdata = ''
            fdata = f.read()
            print(fdata)
            f.close()
            cipher_text = onetimepad.encrypt(fdata, 'random')

            print(cipher_text)

            val = (key1, fname, oname, cipher_text, status,permission)
            mycursor.execute(sql, val)
            mydb.commit()
        else:
            return render_template("udocuments.html", msg='File already Exists!!!')
        mydb.close()
    return render_template("udocuments.html", msg='File Uploaded Successfully!!!')



@app.route('/vdocumnts')
def vdocumnts():
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="",
        database="multicloud"
    )
    mycursor = mydb.cursor()

    sql = "select id,private_key,trapdoor_key,username,filee from uploadedfiles"
    mycursor.execute(sql)
    users = pd.DataFrame(mycursor.fetchall())
    rows = mycursor.rowcount
    if rows != 0:
        users.columns = ['Id', 'Private Key', 'Trapdoor', 'User Name', 'File']
    if rows == 0:
        return render_template("vdocumnts.html", msg='null')
    mydb.close()
    return render_template("vdocumnts.html", data=users.to_html(index=False))


@app.route('/vusers')
def vusers():
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="",
        database="multicloud"
    )
    mycursor = mydb.cursor()

    sql = "select * from datausersignup"
    mycursor.execute(sql)
    users = pd.DataFrame(mycursor.fetchall())
    rows = mycursor.rowcount
    if rows != 0:
        users.columns = ['Id', 'Name', 'User Name', 'Password', 'Mobile']
    if rows == 0:
        return render_template("vusers.html", msg='null')
    mydb.close()
    return render_template("vusers.html", data=users.to_html(index=False))


@app.route('/vowners')
def vowners():
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="",
        database="multicloud"
    )
    mycursor = mydb.cursor()

    sql = "select * from dataownersignup"
    mycursor.execute(sql)
    users = pd.DataFrame(mycursor.fetchall())
    rows = mycursor.rowcount
    if rows != 0:
        users.columns = ['Id', 'Name', 'User Name', 'Password', 'Mobile']
    if rows == 0:
        return render_template("vowners.html", msg='null')
    mydb.close()
    return render_template("vowners.html", data=users.to_html(index=False))


@app.route('/searchbloom', methods=['POST', 'GET'])
def searchbloom():

    global abc
    if request.method == 'POST':
        keywor = request.form['key']
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            passwd="",
            database="multicloud"
        )
        mycursor = mydb.cursor()
        sql = "SELECT filee , username from uploadedfiles where trapdoor_key=%s and status='nil' and permission='nil'"
        val = (keywor,)
        mycursor.execute(sql, val)
        abc = pd.DataFrame(mycursor.fetchall())
        rows = mycursor.rowcount
        print('number of rows',rows)
        if rows != 0:
            abc.columns = ['Document', 'User Name']
            print(abc)
            return render_template('searchbloom.html',abc=abc)
        mydb.close()
    return render_template('searchbloom.html',msg='null')


@app.route('/search/<key1>', methods=['POST', 'GET'])
def enroll(key1):
    global key2
    key2 = key1
    return render_template("search.html")


@app.route('/ask/<id>', methods=['POST', 'GET'])
def ask(id):

    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="",
        database="multicloud"
    )
    mycursor = mydb.cursor()
    sql = "update uploadedfiles set permission='user_request' where username=%s"
    vals=(id,)
    mycursor.execute(sql,vals)
    mydb.commit()
    return render_template("gouser.html")


@app.route('/searchpermission/')
def searchpermission():

    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="",
        database="multicloud"
    )
    mycursor = mydb.cursor()

    sql = "select * from  uploadedfiles where status='nil' and permission ='user_request' "
    mycursor.execute(sql)
    aaa = pd.DataFrame(mycursor.fetchall())
    rows = mycursor.rowcount
    if rows != 0:
        aaa.columns = ['Id', 'Private Key', 'Trapdoor', 'User Name', 'File', 'Status', 'Permission']
        return render_template("searchpermission.html", aaa=aaa)

    mydb.close()
    return render_template("searchpermission.html", msg='null')



@app.route('/access/<id>', methods=['POST', 'GET'])
def access(id):

    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="",
        database="multicloud"
    )
    mycursor = mydb.cursor()
    sql = "update uploadedfiles set permission='access' where username=%s"
    vals=(id,)
    mycursor.execute(sql, vals)
    mydb.commit()
    return render_template("accessgranted.html")

@app.route('/dfile')
def dfile():
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="",
        database="multicloud"
    )
    mycursor = mydb.cursor()
    sql = "select * from uploadedfiles"
    mycursor.execute(sql)
    df = pd.DataFrame(mycursor.fetchall())
    if mycursor.rowcount > 0:
        return render_template('downloadfiles.html',data = df)
    return render_template('downloadfiles.html',msg='failure')

@app.route('/downloadfile/<pkey>/<fname>')
def downloadfile(pkey,fname):
    global key1,filename
    key1=pkey
    filename=fname
    return render_template('downloadfile.html',msg='success')

@app.route('/validatekey',methods=["POST","GET"])
def validatekey():
    if request.method == "POST":
        pkey = request.form['pkey']
        if str(pkey) == key1:
            mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                passwd="",
                database="multicloud"
            )
            mycursor = mydb.cursor()
            sql = "select filee from uploadedfiles where trapdoor_key = %s"
            vals = (filename,)
            mycursor.execute(sql,vals)
            filecontent = mycursor.fetchone()[0]
            decrypt_text = onetimepad.decrypt(filecontent, 'random')
            file_name = "e:/files1/" + filename + ".txt"
            f = open(file_name, 'w')
            f.write(decrypt_text)
            print(decrypt_text)
            f.close()
            return render_template('filedownloadsuccess.html')
        return render_template('downloadfile.html',msg='failure')

if __name__ == '__main__':
 app.run(debug=True)
