/*
SQLyog Enterprise - MySQL GUI v6.56
MySQL - 5.5.5-10.1.13-MariaDB : Database - multicloud
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`multicloud` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `multicloud`;

/*Table structure for table `dataownersignup` */

DROP TABLE IF EXISTS `dataownersignup`;

CREATE TABLE `dataownersignup` (
  `id` int(30) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `mobile` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `dataownersignup` */

insert  into `dataownersignup`(`id`,`name`,`username`,`password`,`mobile`) values (2,'rama','rama@gmail.com','1234','9988007788');

/*Table structure for table `datausersignup` */

DROP TABLE IF EXISTS `datausersignup`;

CREATE TABLE `datausersignup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `mobile` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `datausersignup` */

insert  into `datausersignup`(`id`,`name`,`username`,`password`,`mobile`) values (1,'prakash','prakash@gmail.com','1234','9988776644');

/*Table structure for table `uploadedfiles` */

DROP TABLE IF EXISTS `uploadedfiles`;

CREATE TABLE `uploadedfiles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `private_key` varchar(30) DEFAULT NULL,
  `trapdoor_key` varchar(30) DEFAULT NULL,
  `username` varchar(30) DEFAULT NULL,
  `filee` varchar(30) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `permission` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `uploadedfiles` */

insert  into `uploadedfiles`(`id`,`private_key`,`trapdoor_key`,`username`,`filee`,`status`,`permission`) values (5,'1620','cloud','cloud','310d01110b4d110e03141a191b0f09','nil','access'),(6,'2','cloud','rama','310d01110b4d110e03141a191b0f09','nil','access');

/*Table structure for table `userregister` */

DROP TABLE IF EXISTS `userregister`;

CREATE TABLE `userregister` (
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `userregister` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
